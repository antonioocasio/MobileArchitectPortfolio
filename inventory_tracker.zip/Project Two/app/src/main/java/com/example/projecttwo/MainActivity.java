package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {
    private EditText editTextUserName, editTextPassword;
    private Button buttonSubmit, buttonCreateUser;
    private UserDatabase userDB;
    private String username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUserName = findViewById(R.id.editTextUserName);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonCreateUser = findViewById(R.id.buttonCreateUser);
        buttonSubmit.setEnabled(false);

        userDB = new UserDatabase(MainActivity.this);

        editTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    buttonSubmit.setEnabled(false);
                } else {
                    buttonSubmit.setEnabled(true);
                }
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // launch LoggedIn activity
                username = editTextUserName.getText().toString();
                password = editTextPassword.getText().toString();

                userDB.addNewUser(username, password);
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_LONG).show();

                openLoggedIn();


            }
        });

        buttonCreateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // launch create user activity
                openCreateUser();
            }
        });
    }

    public void openCreateUser() {
        Intent intent = new Intent(this, CreateUser.class);
        startActivity(intent);
    }

    public void openLoggedIn() {
        Intent intent = new Intent(this, LoggedIn.class);
        startActivity(intent);
    }

}