package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateUser extends AppCompatActivity {
    private Button buttonSubmit;
    private String username, password;
    private UserDatabase userDB = new UserDatabase(CreateUser.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        buttonSubmit = findViewById(R.id.buttonSubmit);
        Button buttonCancel = findViewById(R.id.buttonCancel);
        EditText editTextCreateUserName = findViewById(R.id.editTextCreateUserName);
        EditText editTextCreatePassword = findViewById(R.id.editTextCreatePassword);
        buttonSubmit.setEnabled(false);

        editTextCreatePassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    buttonSubmit.setEnabled(false);
                } else {
                    buttonSubmit.setEnabled(true);
                }
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // cancel user creation
                cancelCreation();
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // launch LoggedIn activity
                username = editTextCreateUserName.getText().toString();
                password = editTextCreatePassword.getText().toString();

                userDB.addNewUser(username, password);
                Toast.makeText(CreateUser.this, "Account Created Successfully", Toast.LENGTH_LONG).show();

                openLoggedIn();


            }
        });

    }

    // intent for cancel
    public void cancelCreation() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // intent for logging in
    public void openLoggedIn() {
        Intent intent = new Intent(this, LoggedIn.class);
        startActivity(intent);
    }

}